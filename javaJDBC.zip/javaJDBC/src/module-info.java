module javaJDBC {
	requires java.sql;
}